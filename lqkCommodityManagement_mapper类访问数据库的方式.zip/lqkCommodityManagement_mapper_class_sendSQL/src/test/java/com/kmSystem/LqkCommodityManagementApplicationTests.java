package com.kmSystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LqkCommodityManagementApplicationTests {

    @Test
    void contextLoads() {
    }

}
