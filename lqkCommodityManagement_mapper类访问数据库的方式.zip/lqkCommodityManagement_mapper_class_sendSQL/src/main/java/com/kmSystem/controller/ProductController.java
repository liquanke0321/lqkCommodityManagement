package com.kmSystem.controller;

import com.kmSystem.entity.ProductInfoVo;
import com.kmSystem.service.ProductService;
import com.kmSystem.service.ProductServiceImpl;
import jakarta.annotation.Resource;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
public class ProductController {
    @Resource
    private ProductService productService = new ProductServiceImpl();

    @PostMapping("/api/product/select")
    public List<ProductInfoVo> SelectproductList(@RequestBody ProductInfoVo productInfo) throws Exception {
        List<ProductInfoVo> productInfoVoList = new ArrayList<ProductInfoVo>();
        List<ProductInfoVo> productInfoVoResultList = selectProduct(productInfo);
        if (!productInfoVoResultList.isEmpty()) {
            return productInfoVoResultList;
        }
        return productInfoVoList;
    }

    @RequestMapping(value = "/selectProduct", method = RequestMethod.GET)
    public List<ProductInfoVo> selectProduct(ProductInfoVo productInfo) {
        ProductInfoVo productInfoSql = new ProductInfoVo();
        List<ProductInfoVo> list = new ArrayList<ProductInfoVo>();
        int flg = 0;
        if (productInfo.getProduct_id() != null && productInfo.getProduct_id() != "") {// 根据商品编码查询
            productInfoSql.setProduct_id(productInfo.getProduct_id());
        }
        if (productInfo.getProduct_type() != null && productInfo.getProduct_type() != "") {// 根据商品类型查找
            productInfoSql.setProduct_type(productInfo.getProduct_type());
        }
        if (productInfo.getProduct_name() != null && productInfo.getProduct_name() != "") {// 根据商品名称查找
            productInfoSql.setProduct_name(productInfo.getProduct_name());
        }
        System.out.println(productInfoSql);

        list = productService.selectProduct(productInfoSql);

        return list;
    }
}